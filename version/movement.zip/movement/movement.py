# -*- coding: utf-8 -*- 

import fileinput

# weekend:19,25,26
# weekday:20,21,22,23,24
def euclidean(p1,p2):
	from math import sqrt
	dist = sqrt(sum([pow(i-j,2) for i,j in zip(p1,p2)]))
	return dist

def test():
	c = 0
	file = open("out.txt","w")
	for line in fileinput.input("move.txt"):
		c += 1
		print c
		seq = [[int(j) for j in i.split(",")] for i in line.strip().split(" ")[1:]]
		items, i, j = [], 0, 1
		while i<=len(seq)-2:
			ps = [tuple(seq[i][1:])]
			while j<=len(seq)-1:
				if euclidean(seq[i][1:],seq[j][1:]) <= 5: #1000 meters
					ps.append(tuple(seq[j][1:]))
					j+=1
				else:
					for k in range(j+1,min(j+6,len(seq)-1)): #stable leave?
						if seq[k][0]-seq[j][0]<=5 and euclidean(seq[i][1:],seq[k][1:])<=5:
							j = k
					if euclidean(seq[i][1:],seq[j][1:])>5 and seq[j-1][0]-seq[i][0]>=6:
						items.append((seq[i][0],seq[j-1][0],set(ps)))
					break
			i, j = j, j+1
		for i in xrange(len(items)):
			# if ((i>=1 and items[i][0]-items[i-1][1]<=6) or i==0) and ((i<=len(items)-2 and items[i+1][0]-items[i][1]<=6) or i==len(items)-1):
			print i, items[i][0]/6, items[i][1]/6, items[i][2]
		# if len(items)!=0:
		# 	file.write(" ".join([str(i[0]/6)+","+str(i[1]/6) for i in items])+"\n")
	fileinput.close()
	file.close()
		
	# colormap = []
	# for line in fileinput.input("test.txt"):
	# 	items =	line.strip().split(" ")
	# 	if len(items) >= 2:
	# 		seqs, c = [0.0]*24, 0
	# 		for item in items:
	# 			print item
	# 			for i in range(int(item.split(",")[0]),int(item.split(",")[1])+1):
	# 				if c == 0:
	# 					seqs[i] = 0.9
	# 				if c == 1:
	# 					seqs[i] = 0.6
	# 				if c == 2:
	# 					seqs[i] = 0.8
	# 				if c == 3:
	# 					seqs[i] = 0.5
	# 				if c == 4:
	# 					seqs[i] = 0.7
	# 				if c == 5:
	# 					seqs[i] = 0.4
	# 			c += 1
	# 		colormap.append(seqs)
	# import matplotlib.pyplot as plt
	# import numpy as np
	# (X, Y), C = np.meshgrid(np.arange(25), np.arange(len(colormap)+1)), np.array(colormap)
	# plt.subplot(111)
	# plt.pcolormesh(X,Y,C)
	# plt.axis('off')
	# plt.show()

test()

